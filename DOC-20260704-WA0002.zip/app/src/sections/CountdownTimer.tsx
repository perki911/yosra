import { useState, useEffect, useRef } from "react";
import { motion, useInView } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { config } from "@/config";

interface TimeLeft {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

function getTimeLeft(targetDate: string): TimeLeft {
  const difference = new Date(targetDate).getTime() - new Date().getTime();
  if (difference <= 0) {
    return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  }
  return {
    days: Math.floor(difference / (1000 * 60 * 60 * 24)),
    hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((difference / 1000 / 60) % 60),
    seconds: Math.floor((difference / 1000) % 60),
  };
}

function AnalogClock() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);

  const seconds = time.getSeconds();
  const minutes = time.getMinutes();
  const hours = time.getHours();

  const secondDegrees = seconds * 6;
  const minuteDegrees = minutes * 6 + seconds * 0.1;
  const hourDegrees = (hours % 12) * 30 + minutes * 0.5;

  return (
    <div
      className="relative w-[120px] h-[120px] rounded-full border-2 mx-auto mt-8"
      style={{ borderColor: "var(--rich-gold)" }}
    >
      {/* Hour markers */}
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={i}
          className="absolute w-1 h-1 rounded-full"
          style={{
            backgroundColor: "var(--rich-gold)",
            top: "50%",
            left: "50%",
            transform: `rotate(${i * 30}deg) translateY(-52px) translate(-50%, -50%)`,
          }}
        />
      ))}

      {/* Hour hand */}
      <div
        className="absolute top-1/2 left-1/2 origin-bottom rounded-full"
        style={{
          width: "3px",
          height: "32px",
          backgroundColor: "var(--rich-gold)",
          transform: `translate(-50%, -100%) rotate(${hourDegrees}deg)`,
          transformOrigin: "50% 100%",
        }}
      />

      {/* Minute hand */}
      <div
        className="absolute top-1/2 left-1/2 origin-bottom rounded-full"
        style={{
          width: "2px",
          height: "42px",
          backgroundColor: "var(--rich-gold)",
          transform: `translate(-50%, -100%) rotate(${minuteDegrees}deg)`,
          transformOrigin: "50% 100%",
        }}
      />

      {/* Second hand */}
      <div
        className="absolute top-1/2 left-1/2 origin-bottom rounded-full"
        style={{
          width: "1px",
          height: "46px",
          backgroundColor: "var(--deep-gold)",
          transform: `translate(-50%, -100%) rotate(${secondDegrees}deg)`,
          transformOrigin: "50% 100%",
        }}
      />

      {/* Center dot */}
      <div
        className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full -translate-x-1/2 -translate-y-1/2"
        style={{ backgroundColor: "var(--rich-gold)" }}
      />
    </div>
  );
}

export default function CountdownTimer() {
  const [timeLeft, setTimeLeft] = useState<TimeLeft>(() =>
    getTimeLeft(config.weddingDate)
  );
  const [changedUnit, setChangedUnit] = useState<string | null>(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.2 });

  useEffect(() => {
    const interval = setInterval(() => {
      const newTimeLeft = getTimeLeft(config.weddingDate);
      setTimeLeft((prev) => {
        if (prev.seconds !== newTimeLeft.seconds) setChangedUnit("seconds");
        else if (prev.minutes !== newTimeLeft.minutes) setChangedUnit("minutes");
        else if (prev.hours !== newTimeLeft.hours) setChangedUnit("hours");
        else if (prev.days !== newTimeLeft.days) setChangedUnit("days");
        return newTimeLeft;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (changedUnit) {
      const timeout = setTimeout(() => setChangedUnit(null), 300);
      return () => clearTimeout(timeout);
    }
  }, [changedUnit]);

  const isToday =
    timeLeft.days === 0 &&
    timeLeft.hours === 0 &&
    timeLeft.minutes === 0 &&
    timeLeft.seconds === 0;

  const units = [
    { key: "days", label: "يوم", value: timeLeft.days },
    { key: "hours", label: "ساعة", value: timeLeft.hours },
    { key: "minutes", label: "دقيقة", value: timeLeft.minutes },
    { key: "seconds", label: "ثانية", value: timeLeft.seconds },
  ];

  return (
    <section
      ref={ref}
      className="relative min-h-[80dvh] flex flex-col items-center justify-center py-20 px-6 overflow-hidden"
      style={{ backgroundColor: "var(--soft-cream)" }}
    >
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{
          backgroundImage: "url('/images/bg-countdown.jpg')",
          backgroundPosition: "center bottom",
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center max-w-lg mx-auto w-full">
        {/* Section Title */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="flex flex-col items-center mb-3"
        >
          <div
            className="w-16 h-0.5 mb-4"
            style={{ backgroundColor: "var(--rich-gold)" }}
          />
          <h2
            className="font-scheherazade text-3xl md:text-4xl font-bold"
            style={{ color: "var(--rich-gold)" }}
          >
            العد التنازلي
          </h2>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="font-amiri text-base mb-10"
          style={{ color: "var(--medium-brown)" }}
        >
          لحظات تفصلنا عن اللقاء
        </motion.p>

        {/* Countdown Grid */}
        {isToday ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={isInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.8 }}
            className="text-center mb-8"
          >
            <span
              className="font-amiri text-4xl md:text-5xl font-bold"
              style={{ color: "var(--rich-gold)" }}
            >
              اليوم!
            </span>
          </motion.div>
        ) : (
          <div className="flex gap-3 mb-8">
            {units.map((unit, index) => (
              <motion.div
                key={unit.key}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={`flex flex-col items-center justify-center w-20 h-24 rounded-lg border bg-white/80 backdrop-blur-sm ${
                  changedUnit === unit.key ? "countdown-pulse" : ""
                }`}
                style={{
                  borderColor: "rgba(212, 168, 83, 0.3)",
                  boxShadow: "0 2px 8px rgba(74, 55, 40, 0.06)",
                }}
              >
                <span
                  className="font-tajawal text-3xl md:text-4xl font-bold"
                  style={{ color: "var(--dark-brown)" }}
                >
                  {String(unit.value).padStart(2, "0")}
                </span>
                <span
                  className="font-tajawal text-xs mt-1"
                  style={{ color: "var(--medium-brown)" }}
                >
                  {unit.label}
                </span>
              </motion.div>
            ))}
          </div>
        )}

        {/* Analog Clock */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
        >
          <AnalogClock />
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex flex-col items-center mt-10"
        >
          <ChevronDown
            className="w-5 h-5 bounce-subtle"
            style={{ color: "var(--medium-brown)" }}
          />
          <span
            className="font-tajawal text-sm mt-2"
            style={{ color: "var(--medium-brown)" }}
          >
            اسحب للأسفل
          </span>
        </motion.div>
      </div>
    </section>
  );
}
