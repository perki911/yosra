import { useState, useRef } from "react";
import { motion, useInView, AnimatePresence } from "framer-motion";
import {
  MapPin,
  X,
  ExternalLink,
  Wine,
  Camera,
  UtensilsCrossed,
  Music,
  Gem,
} from "lucide-react";
import { config, type EventItem } from "@/config";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import type { LatLngExpression } from "leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Fix Leaflet marker icons
import markerIcon2x from "leaflet/dist/images/marker-icon-2x.png";
import markerIcon from "leaflet/dist/images/marker-icon.png";
import markerShadow from "leaflet/dist/images/marker-shadow.png";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: markerIcon2x,
  iconUrl: markerIcon,
  shadowUrl: markerShadow,
});

const goldIcon = new L.Icon({
  iconUrl:
    "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 36'%3E%3Cpath d='M12 0C5.4 0 0 5.4 0 12c0 9 12 24 12 24s12-15 12-24c0-6.6-5.4-12-12-12z' fill='%23D4A853'/%3E%3Ccircle cx='12' cy='12' r='5' fill='white'/%3E%3C/svg%3E",
  iconSize: [28, 42],
  iconAnchor: [14, 42],
  popupAnchor: [0, -36],
});

const iconMap: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  ring: Gem,
  cocktail: Wine,
  camera: Camera,
  utensils: UtensilsCrossed,
  music: Music,
};

function MapModal({
  event,
  onClose,
}: {
  event: EventItem;
  onClose: () => void;
}) {
  const center: LatLngExpression = [event.lat, event.lng];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="fixed inset-0 z-50 flex items-end justify-center"
      onClick={onClose}
    >
      {/* Backdrop */}
      <div className="absolute inset-0 bg-black/50" />

      {/* Modal */}
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        onClick={(e) => e.stopPropagation()}
        className="relative w-full max-w-lg rounded-t-3xl p-6"
        style={{ backgroundColor: "var(--warm-white)" }}
      >
        {/* Header */}
        <div className="flex items-center justify-between mb-4">
          <h3
            className="font-amiri text-xl font-bold"
            style={{ color: "var(--dark-brown)" }}
          >
            {event.title}
          </h3>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-black/5 transition-colors"
          >
            <X className="w-6 h-6" style={{ color: "var(--medium-brown)" }} />
          </button>
        </div>

        {/* Map */}
        <div className="rounded-lg overflow-hidden mb-4 h-[300px]">
          <MapContainer
            center={center}
            zoom={15}
            scrollWheelZoom={false}
            style={{ height: "100%", width: "100%" }}
          >
            <TileLayer
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
            />
            <Marker position={center} icon={goldIcon}>
              <Popup>
                <span className="font-tajawal">{event.locationName}</span>
              </Popup>
            </Marker>
          </MapContainer>
        </div>

        {/* Address */}
        <p
          className="font-amiri text-base mb-4 text-center"
          style={{ color: "var(--dark-brown)" }}
        >
          {event.locationAddress}
        </p>

        {/* Open in Google Maps */}
        <a
          href={`https://www.google.com/maps?q=${event.lat},${event.lng}`}
          target="_blank"
          rel="noopener noreferrer"
          className="btn-gold flex items-center justify-center gap-2 w-full py-3.5 rounded-xl font-tajawal font-medium text-base"
        >
          <span>افتح في خرائط جوجل</span>
          <ExternalLink className="w-4 h-4" />
        </a>
      </motion.div>
    </motion.div>
  );
}

function EventCard({
  event,
  index,
  isInView,
  onOpenMap,
}: {
  event: EventItem;
  index: number;
  isInView: boolean;
  onOpenMap: (event: EventItem) => void;
}) {
  const IconComponent = iconMap[event.icon] || MapPin;
  const isLeft = index % 2 === 0;

  return (
    <motion.div
      initial={{ opacity: 0, x: isLeft ? -30 : 30 }}
      animate={isInView ? { opacity: 1, x: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.15 }}
      className={`relative flex items-start ${isLeft ? "flex-row" : "flex-row-reverse"} w-full mb-8`}
    >
      {/* Card */}
      <div
        className={`w-[45%] rounded-xl p-5 ${isLeft ? "ml-auto mr-4" : "mr-auto ml-4"}`}
        style={{
          backgroundColor: "var(--soft-cream)",
          boxShadow: "0 2px 12px rgba(74, 55, 40, 0.08)",
        }}
      >
        {/* Icon */}
        <div
          className="w-10 h-10 rounded-full flex items-center justify-center mb-3"
          style={{ backgroundColor: "rgba(212, 168, 83, 0.15)" }}
        >
          <IconComponent
            className="w-5 h-5"
            style={{ color: "var(--rich-gold)" }}
          />
        </div>

        {/* Date */}
        <p
          className="font-tajawal text-xs mb-1"
          style={{ color: "var(--medium-brown)" }}
        >
          {event.date}
        </p>

        {/* Title */}
        <h4
          className="font-amiri text-lg font-bold mb-1"
          style={{ color: "var(--dark-brown)" }}
        >
          {event.title}
        </h4>

        {/* Time */}
        <p
          className="font-amiri text-sm mb-3"
          style={{ color: "var(--medium-brown)" }}
        >
          {event.dayName} {event.time}
        </p>

        {/* Location Button */}
        <button
          onClick={() => onOpenMap(event)}
          className="inline-flex items-center gap-1.5 px-5 py-2 rounded-full border font-tajawal text-sm transition-all hover:scale-105 cursor-pointer"
          style={{
            borderColor: "var(--rich-gold)",
            color: "var(--rich-gold)",
          }}
        >
          <MapPin className="w-4 h-4" />
          <span>الموقع</span>
        </button>
      </div>

      {/* Timeline Dot */}
      <motion.div
        initial={{ scale: 0 }}
        animate={isInView ? { scale: 1 } : {}}
        transition={{ duration: 0.3, delay: index * 0.15 + 0.2 }}
        className="absolute left-1/2 -translate-x-1/2 top-6 w-3 h-3 rounded-full timeline-dot-pulse"
        style={{ backgroundColor: "var(--rich-gold)" }}
      />
    </motion.div>
  );
}

export default function EventProgram() {
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.1 });

  return (
    <>
      <section
        ref={ref}
        className="relative py-20 px-6"
        style={{ backgroundColor: "var(--warm-white)" }}
      >
        <div className="max-w-lg mx-auto">
          {/* Section Title */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="flex flex-col items-center mb-12"
          >
            <div
              className="w-16 h-0.5 mb-4"
              style={{ backgroundColor: "var(--rich-gold)" }}
            />
            <h2
              className="font-scheherazade text-3xl md:text-4xl font-bold"
              style={{ color: "var(--rich-gold)" }}
            >
              برنامج الحفل
            </h2>
          </motion.div>

          {/* Timeline */}
          <div className="relative">
            {/* Vertical Line */}
            <motion.div
              initial={{ height: 0 }}
              animate={isInView ? { height: "100%" } : {}}
              transition={{ duration: 1, ease: "easeOut" }}
              className="absolute left-1/2 -translate-x-1/2 top-0 w-0.5"
              style={{ backgroundColor: "rgba(212, 168, 83, 0.3)" }}
            />

            {/* Events */}
            {config.events.map((event, index) => (
              <EventCard
                key={event.id}
                event={event}
                index={index}
                isInView={isInView}
                onOpenMap={setSelectedEvent}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Map Modal */}
      <AnimatePresence>
        {selectedEvent && (
          <MapModal
            event={selectedEvent}
            onClose={() => setSelectedEvent(null)}
          />
        )}
      </AnimatePresence>
    </>
  );
}
