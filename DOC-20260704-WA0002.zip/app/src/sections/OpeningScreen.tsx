import { motion } from "framer-motion";
import { Heart } from "lucide-react";

interface OpeningScreenProps {
  isVisible: boolean;
  onOpen: () => void;
}

export default function OpeningScreen({ isVisible, onOpen }: OpeningScreenProps) {
  if (!isVisible) return null;

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed inset-0 z-40 flex flex-col items-center justify-center overflow-hidden"
      style={{ backgroundColor: "var(--warm-white)" }}
    >
      {/* Corner Ornaments - Top Left */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="absolute top-0 left-0 w-40 h-40 md:w-48 md:h-48"
        style={{
          background: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cpath d='M10 100 C20 80, 40 60, 60 50 C50 40, 30 30, 20 10 C50 30, 80 40, 100 50 C80 60, 60 80, 50 100 C60 120, 80 140, 100 150 C80 160, 50 170, 20 190 C30 170, 50 150, 60 130 C40 120, 20 110, 10 100Z' fill='%23D4A853'/%3E%3Cpath d='M100 10 C110 30, 120 50, 130 60 C150 50, 170 30, 190 20 C170 50, 160 80, 150 100 C140 80, 120 60, 100 50 C90 40, 80 30, 100 10Z' fill='%23D4A853'/%3E%3C/svg%3E") no-repeat center`,
          backgroundSize: "contain",
          transform: "scaleX(-1)",
        }}
      />

      {/* Corner Ornaments - Top Right */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 0.6, delay: 0.3 }}
        className="absolute top-0 right-0 w-40 h-40 md:w-48 md:h-48"
        style={{
          background: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cpath d='M10 100 C20 80, 40 60, 60 50 C50 40, 30 30, 20 10 C50 30, 80 40, 100 50 C80 60, 60 80, 50 100 C60 120, 80 140, 100 150 C80 160, 50 170, 20 190 C30 170, 50 150, 60 130 C40 120, 20 110, 10 100Z' fill='%23D4A853'/%3E%3Cpath d='M100 10 C110 30, 120 50, 130 60 C150 50, 170 30, 190 20 C170 50, 160 80, 150 100 C140 80, 120 60, 100 50 C90 40, 80 30, 100 10Z' fill='%23D4A853'/%3E%3C/svg%3E") no-repeat center`,
          backgroundSize: "contain",
        }}
      />

      {/* Corner Ornaments - Bottom Left */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="absolute bottom-0 left-0 w-40 h-40 md:w-48 md:h-48"
        style={{
          background: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cpath d='M10 100 C20 80, 40 60, 60 50 C50 40, 30 30, 20 10 C50 30, 80 40, 100 50 C80 60, 60 80, 50 100 C60 120, 80 140, 100 150 C80 160, 50 170, 20 190 C30 170, 50 150, 60 130 C40 120, 20 110, 10 100Z' fill='%23D4A853'/%3E%3Cpath d='M100 10 C110 30, 120 50, 130 60 C150 50, 170 30, 190 20 C170 50, 160 80, 150 100 C140 80, 120 60, 100 50 C90 40, 80 30, 100 10Z' fill='%23D4A853'/%3E%3C/svg%3E") no-repeat center`,
          backgroundSize: "contain",
          transform: "scaleX(-1) scaleY(-1)",
        }}
      />

      {/* Corner Ornaments - Bottom Right */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.3 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="absolute bottom-0 right-0 w-40 h-40 md:w-48 md:h-48"
        style={{
          background: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Cpath d='M10 100 C20 80, 40 60, 60 50 C50 40, 30 30, 20 10 C50 30, 80 40, 100 50 C80 60, 60 80, 50 100 C60 120, 80 140, 100 150 C80 160, 50 170, 20 190 C30 170, 50 150, 60 130 C40 120, 20 110, 10 100Z' fill='%23D4A853'/%3E%3Cpath d='M100 10 C110 30, 120 50, 130 60 C150 50, 170 30, 190 20 C170 50, 160 80, 150 100 C140 80, 120 60, 100 50 C90 40, 80 30, 100 10Z' fill='%23D4A853'/%3E%3C/svg%3E") no-repeat center`,
          backgroundSize: "contain",
          transform: "scaleY(-1)",
        }}
      />

      {/* Side Ornaments - Left */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.15 }}
        transition={{ duration: 0.8, delay: 0.3 }}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-16 h-3/4 hidden md:block"
        style={{
          background: `repeating-linear-gradient(
            180deg,
            transparent,
            transparent 40px,
            rgba(212, 168, 83, 0.3) 40px,
            rgba(212, 168, 83, 0.3) 41px
          )`,
        }}
      />

      {/* Side Ornaments - Right */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.15 }}
        transition={{ duration: 0.8, delay: 0.4 }}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-16 h-3/4 hidden md:block"
        style={{
          background: `repeating-linear-gradient(
            180deg,
            transparent,
            transparent 40px,
            rgba(212, 168, 83, 0.3) 40px,
            rgba(212, 168, 83, 0.3) 41px
          )`,
        }}
      />

      {/* Center Emblem */}
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="flex flex-col items-center"
      >
        <div
          className="w-[120px] h-[120px] rounded-full flex flex-col items-center justify-center border-2 mb-10"
          style={{ borderColor: "var(--rich-gold)" }}
        >
          <Heart
            className="w-12 h-12"
            fill="#C9A84C"
            stroke="#C9A84C"
          />
          <span
            className="font-amiri text-xl font-bold mt-2"
            style={{ color: "var(--rich-gold)" }}
          >
            دعوة زفاف
          </span>
        </div>

        {/* Welcome Button */}
        <motion.button
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
          onClick={onOpen}
          className="btn-gold px-12 py-3.5 rounded-full font-tajawal font-medium text-base tracking-wide cursor-pointer"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.98 }}
        >
          افتح الدعوة
        </motion.button>

        {/* Hint Text */}
        <motion.span
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="font-tajawal text-sm mt-4"
          style={{ color: "var(--medium-brown)" }}
        >
          اضغط للمتابعة
        </motion.span>
      </motion.div>
    </motion.div>
  );
}
