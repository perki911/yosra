import { motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { config } from "@/config";

export default function HeroInvitation() {
  return (
    <section className="relative min-h-[100dvh] flex flex-col items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: "url('/images/bg-hero.jpg')" }}
      />

      {/* Overlay */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(to bottom, rgba(245, 239, 230, 0.88) 0%, rgba(245, 239, 230, 0.75) 100%)",
        }}
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center text-center px-6 py-20 max-w-lg mx-auto">
        {/* Blessing Quote */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex flex-col items-center mb-6"
        >
          <div
            className="w-10 h-0.5 mb-4"
            style={{ backgroundColor: "var(--rich-gold)" }}
          />
          <p
            className="font-amiri text-lg md:text-xl leading-relaxed"
            style={{ color: "var(--dark-brown)" }}
          >
            {config.blessingText}
          </p>
        </motion.div>

        {/* Invitation Text */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="font-scheherazade text-3xl md:text-4xl font-bold mb-5"
          style={{ color: "var(--rich-gold)", letterSpacing: "0.02em" }}
        >
          {config.invitationText}
        </motion.h2>

        {/* Family Names */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex items-center gap-6 md:gap-8 mb-4"
        >
          {/* Bride's Family (Left in RTL) */}
          <div className="flex flex-col items-center">
            <span
              className="font-amiri text-base"
              style={{ color: "var(--dark-brown)" }}
            >
              {config.brideFather}
            </span>
            <span
              className="font-amiri text-sm"
              style={{ color: "var(--medium-brown)" }}
            >
              والسيدة
            </span>
            <span
              className="font-amiri text-sm"
              style={{ color: "var(--medium-brown)" }}
            >
              {config.brideMother}
            </span>
          </div>

          {/* Ampersand */}
          <span
            className="font-amiri text-3xl font-bold"
            style={{ color: "var(--rich-gold)" }}
          >
            &amp;
          </span>

          {/* Groom's Family (Right in RTL) */}
          <div className="flex flex-col items-center">
            <span
              className="font-amiri text-base"
              style={{ color: "var(--dark-brown)" }}
            >
              {config.groomFather}
            </span>
            <span
              className="font-amiri text-sm"
              style={{ color: "var(--medium-brown)" }}
            >
              والسيدة
            </span>
            <span
              className="font-amiri text-sm"
              style={{ color: "var(--medium-brown)" }}
            >
              {config.groomMother}
            </span>
          </div>
        </motion.div>

        {/* Invitation Message */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.7 }}
          className="font-amiri text-base mb-8"
          style={{ color: "var(--medium-brown)" }}
        >
          بدعوتكم لحضور حفل زفاف نجليهما
        </motion.p>

        {/* Couple Names */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="flex items-center gap-3 md:gap-4"
        >
          <span
            className="font-amiri text-4xl md:text-5xl font-bold"
            style={{ color: "var(--rich-gold)" }}
          >
            {config.groomName}
          </span>
          <span
            className="font-amiri text-3xl md:text-4xl font-bold"
            style={{ color: "var(--deep-gold)" }}
          >
            &amp;
          </span>
          <span
            className="font-amiri text-4xl md:text-5xl font-bold"
            style={{ color: "var(--rich-gold)" }}
          >
            {config.brideName}
          </span>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.6, delay: 1.2 }}
          className="flex flex-col items-center mt-auto pt-16"
        >
          <ChevronDown
            className="w-6 h-6 bounce-subtle"
            style={{ color: "var(--rich-gold)" }}
          />
          <span
            className="font-tajawal text-sm mt-2"
            style={{ color: "var(--medium-brown)" }}
          >
            للمزيد
          </span>
        </motion.div>
      </div>
    </section>
  );
}
