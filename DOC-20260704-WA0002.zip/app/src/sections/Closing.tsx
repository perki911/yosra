import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { config } from "@/config";

export default function Closing() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.3 });

  return (
    <section
      ref={ref}
      className="relative min-h-[60dvh] flex flex-col items-center justify-center py-20 px-6"
      style={{
        background: `linear-gradient(to bottom, var(--warm-white) 0%, var(--soft-cream) 100%)`,
      }}
    >
      <div className="flex flex-col items-center max-w-lg mx-auto text-center">
        {/* Decorative Line */}
        <motion.div
          initial={{ width: 0 }}
          animate={isInView ? { width: 80 } : {}}
          transition={{ duration: 0.6 }}
          className="h-px mb-6"
          style={{ backgroundColor: "rgba(212, 168, 83, 0.5)" }}
        />

        {/* Couple Names */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="flex items-center gap-3 mb-5"
        >
          <span
            className="font-amiri text-3xl md:text-4xl font-bold"
            style={{ color: "var(--rich-gold)" }}
          >
            {config.groomName}
          </span>
          <span
            className="font-amiri text-2xl md:text-3xl font-bold"
            style={{ color: "var(--deep-gold)" }}
          >
            &amp;
          </span>
          <span
            className="font-amiri text-3xl md:text-4xl font-bold"
            style={{ color: "var(--rich-gold)" }}
          >
            {config.brideName}
          </span>
        </motion.div>

        {/* Closing Message */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="font-amiri text-lg md:text-xl mb-8"
          style={{ color: "var(--dark-brown)" }}
        >
          {config.closingText}
        </motion.p>

        {/* Rings Icon */}
        <motion.div
          initial={{ opacity: 0, scale: 0.7 }}
          animate={isInView ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex justify-center"
        >
          <svg
            width="64"
            height="48"
            viewBox="0 0 64 48"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Ring 1 */}
            <ellipse
              cx="26"
              cy="28"
              rx="18"
              ry="18"
              stroke="#D4A853"
              strokeWidth="2"
              fill="none"
            />
            {/* Ring 2 */}
            <ellipse
              cx="38"
              cy="28"
              rx="18"
              ry="18"
              stroke="#D4A853"
              strokeWidth="2"
              fill="none"
            />
            {/* Diamond */}
            <path
              d="M38 10 L42 14 L38 18 L34 14 Z"
              fill="#D4A853"
              stroke="#D4A853"
              strokeWidth="0.5"
            />
            <line
              x1="38"
              y1="6"
              x2="38"
              y2="10"
              stroke="#D4A853"
              strokeWidth="1"
            />
          </svg>
        </motion.div>
      </div>
    </section>
  );
}
