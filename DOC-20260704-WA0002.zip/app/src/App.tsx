import { useState, useEffect, useCallback } from "react";
import { AnimatePresence } from "framer-motion";
import LoadingScreen from "@/sections/LoadingScreen";
import OpeningScreen from "@/sections/OpeningScreen";
import HeroInvitation from "@/sections/HeroInvitation";
import CountdownTimer from "@/sections/CountdownTimer";
import EventProgram from "@/sections/EventProgram";
import Closing from "@/sections/Closing";

function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [showOpening, setShowOpening] = useState(false);
  const [showContent, setShowContent] = useState(false);

  // Loading sequence
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
      setShowOpening(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  const handleOpen = useCallback(() => {
    setShowOpening(false);
    // Small delay to let the fade-out animation complete
    setTimeout(() => {
      setShowContent(true);
    }, 300);
  }, []);

  return (
    <div className="min-h-screen" dir="rtl">
      {/* Loading Screen */}
      <LoadingScreen isLoading={isLoading} />

      {/* Opening Screen */}
      <AnimatePresence>
        {showOpening && (
          <OpeningScreen isVisible={showOpening} onOpen={handleOpen} />
        )}
      </AnimatePresence>

      {/* Main Content */}
      {(showContent || !showOpening) && (
        <main>
          {/* Hero - always visible once opening is dismissed */}
          {showContent && <HeroInvitation />}
          {showContent && <CountdownTimer />}
          {showContent && <EventProgram />}
          {showContent && <Closing />}
        </main>
      )}
    </div>
  );
}

export default App;
