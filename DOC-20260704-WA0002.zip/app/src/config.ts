// ═══════════════════════════════════════════
//  ملف الإعدادات - قم بتعديل هذه القيم حسب حاجتك
//  Config file - Edit these values as needed
// ═══════════════════════════════════════════

export interface EventItem {
  id: string;
  title: string;           // عنوان الفعالية
  date: string;            // التاريخ
  time: string;            // الوقت
  dayName: string;         // اسم اليوم
  locationName: string;    // اسم المكان
  locationAddress: string; // العنوان الكامل
  lat: number;             // خط العرض
  lng: number;             // خط الطول
  icon: 'ring' | 'cocktail' | 'camera' | 'utensils' | 'music';
}

export interface Config {
  // ─── معلومات العروسين ───
  groomName: string;       // اسم العريس
  brideName: string;       // اسم العروس
  groomFather: string;     // والد العريس
  groomMother: string;     // والدة العريس
  brideFather: string;     // والد العروس
  brideMother: string;     // والدة العروس

  // ─── تاريخ الزفاف ───
  weddingDate: string;     // صيغة: YYYY-MM-DDTHH:mm (مثال: 2026-07-13T15:30)
  weddingDateDisplay: string; // للعرض (مثال: 2026/7/13)

  // ─── نصوص مخصصة ───
  blessingText: string;    // نص البركة
  invitationText: string;  // نص الدعوة
  closingText: string;     // نص الختام

  // ─── برنامج الحفل ───
  events: EventItem[];
}

// ✦─── اضبط بياناتك هنا ───✦
export const config: Config = {
  groomName: "وليد",
  brideName: "وردة",
  groomFather: "خالد الشمري",
  groomMother: "فاطمة العنزي",
  brideFather: "عبدالرحمن الدوسري",
  brideMother: "نورة الدوسري",

  weddingDate: "2026-07-13T15:30:00",
  weddingDateDisplay: "2026/7/13",

  blessingText: "بارك الله لهما وبارك عليهما وجمع بينهما في خير",
  invitationText: "نتشرف غالينا",
  closingText: "يسعدنا مشاركتكم هذه الفرحة",

  events: [
    {
      id: "1",
      title: "مراسم العقد",
      date: "2026/7/13",
      time: "3:30 PM",
      dayName: "السبت",
      locationName: "فندق الريتز",
      locationAddress: "شارع الملك فهد، الرياض",
      lat: 24.7136,
      lng: 46.6753,
      icon: "ring",
    },
    {
      id: "2",
      title: "استقبال الضيوف",
      date: "2026/7/13",
      time: "4:30 PM",
      dayName: "السبت",
      locationName: "قاعة الفرسان",
      locationAddress: "حي العليا، الرياض",
      lat: 24.7115,
      lng: 46.6780,
      icon: "cocktail",
    },
    {
      id: "3",
      title: "جلسة تصوير",
      date: "2026/7/13",
      time: "5:00 PM",
      dayName: "السبت",
      locationName: "برج الرصاص",
      locationAddress: "حي النخيل، الرياض",
      lat: 24.7681,
      lng: 46.6012,
      icon: "camera",
    },
    {
      id: "4",
      title: "مأدبة العشاء",
      date: "2026/7/13",
      time: "6:30 PM",
      dayName: "السبت",
      locationName: "قاعة المركاز",
      locationAddress: "طريق الأمير محمد بن سلمان، الرياض",
      lat: 24.7408,
      lng: 46.6326,
      icon: "utensils",
    },
    {
      id: "5",
      title: "حفل الأفراح",
      date: "2026/7/13",
      time: "8:00 PM",
      dayName: "السبت",
      locationName: "قاعة الموازين",
      locationAddress: "حي الملقا، الرياض",
      lat: 24.7853,
      lng: 46.5966,
      icon: "music",
    },
  ],
};
